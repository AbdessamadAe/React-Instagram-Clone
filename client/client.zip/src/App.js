import './App.css';
import Home from "./Home/Home"

function App(props) {
  return (
    <div className="container">
      <Home />
    </div>
  );
}

export default App;
